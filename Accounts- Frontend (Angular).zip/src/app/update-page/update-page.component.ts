import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountDto } from '../AccountModel';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-update-page',
  templateUrl: './update-page.component.html',
  styleUrls: ['./update-page.component.css']
})
export class UpdatePageComponent implements OnInit {
  updateForm!: FormGroup;
  errorMessage: any;
  successMessage: any;
  s: any;
  constructor(private fb: FormBuilder, private service: UserServiceService, private router: Router) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state;
    this.s = state;
    console.log(this.s);
  }

  ngOnInit(): void {
    this.updateForm = this.fb.group({
      name: [''],
      oldPassword: ['', Validators.required],
      newPassword: [''],
      cNewPassword: ['']
    });
  }
  submit() {
    if (this.updateForm.value.newPassword == this.updateForm.value.cNewPassword) {
      let data: AccountDto = {
        account_name: this.updateForm.value.name,
        account_password: this.updateForm.value.newPassword,
        old_password: this.updateForm.value.oldPassword,
        account_email: this.s.key.key,
        account_type: ''
      };
      this.service.updateExistingUser(data).subscribe(res => {
        console.log(res)
        if (res == "Unauthorised User! Check the password and try again.") {
          this.errorMessage = res;
        } else {
          this.successMessage = res;
        }


      },

      );
    }
    else
      this.errorMessage = "New password do not match confirm password!";
  }


}

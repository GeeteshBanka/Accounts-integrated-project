import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountDto } from '../AccountModel';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  loginForm!: FormGroup;
  errorMessage: any;
  emailerrormessage: any;
  constructor(private fb: FormBuilder, private service: UserServiceService, private router: Router) { }
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required]],
      password: ['', Validators.required]
    });
  }
  // accountDto: AccountDto = {
  //   account_name: '',
  //   account_password: '',
  //   old_password: '',
  //   account_email: '',
  //   account_type: ''
  // };
  pass: String = '';
  checkPassword() {
    this.service.userLogin(this.loginForm.value.email).subscribe((res: any) => {
      this.pass = res;
      console.log(res);
      if (res === "Email Id entered is wrong!") {
        this.emailerrormessage = "Wrong e-mail id!";
        console.log(this.emailerrormessage);
      }
      else {
        if (this.loginForm.value.password == this.pass) {
          this.router.navigate(["/home"], { state: { key: this.loginForm.value.email } });
        }
        else {
          this.errorMessage = "Worng Password!!";
          console.log(this.errorMessage);
        }
      }
    }


      //this.emailerrormessage = errRes.error.message

    );
  }
  passwrd: boolean = false;

  password() {
    this.passwrd = !this.passwrd;
  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AccountDto } from './AccountModel';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  url = "http://localhost:8401/accounts/";
  constructor(private http: HttpClient) { }

  createNewUser(accountData: any) {
    return this.http.post(this.url + "new", accountData, { responseType: 'text' })

  }

  updateExistingUser(updateData: any) {
    return this.http.put(this.url + "update", updateData, { responseType: 'text' })

  }
  password: String = '';
  userLogin(email: String): Observable<String> {
    console.log(this.http.get(this.url + email, { responseType: 'text' }));
    return this.http.get(this.url + email, { responseType: 'text' });
  }

}

export interface AccountDto {
    account_name: String,
    account_password: String,
    account_email: String,
    account_type: String,
    old_password: String
}
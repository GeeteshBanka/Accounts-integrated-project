import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountDto } from '../AccountModel';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-sign-up-page',
  templateUrl: './sign-up-page.component.html',
  styleUrls: ['./sign-up-page.component.css']
})
export class SignUpPageComponent implements OnInit {
  signupForm!: FormGroup;
  errorMessage: any;
  constructor(private fb: FormBuilder, private service: UserServiceService, private router: Router) { }

  ngOnInit(): void {
    this.signupForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
      cPassword: ['', Validators.required],
      accType: ['', Validators.required]
    });
  }

  submit() {
    if (this.signupForm.value.password == this.signupForm.value.cPassword) {
      let data: AccountDto = {
        account_name: this.signupForm.value.name,
        account_password: this.signupForm.value.password,
        account_email: this.signupForm.value.email,
        account_type: this.signupForm.value.accType,
        old_password: ''
      };
      this.service.createNewUser(data).subscribe(res => {
        console.log(res)
        if (res == "Account already exists!") {
          this.errorMessage = "Email-id is already used!";
        }
        else
          this.router.navigateByUrl("/home");
      }
      );
    }
    else
      this.errorMessage = "Password and confirm password not matching!";
  }

}

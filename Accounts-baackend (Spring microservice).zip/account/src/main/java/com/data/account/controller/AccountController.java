package com.data.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.data.account.dto.AccountDto;
import com.data.account.service.AccountServiceImpl;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


	

@RestController
@RequestMapping("/accounts")
public class AccountController {
	
	
	

@Autowired
private AccountServiceImpl accountService;
	
@CrossOrigin(origins = "*", allowedHeaders = "*")
@PostMapping("/new")
public String addNewAccount(@RequestBody AccountDto accountDto) {

	return accountService.createNewAccount(accountDto);
}

@CrossOrigin(origins = "*", allowedHeaders = "*")
@HystrixCommand(fallbackMethod="updateAccountDetailsFallback")
@PutMapping("/update")
public String updateAccountDetails(@RequestBody AccountDto updateDto)throws Exception{
	return accountService.updateAccoutDetails(updateDto);
}
public String  updateAccountDetailsFallback(@RequestBody AccountDto updateDto) {
	return "Unauthorised User! Check the password and try again.";
}

@CrossOrigin(origins = "*", allowedHeaders = "*")
@HystrixCommand(fallbackMethod="getPasswordFallback")
@GetMapping("/{email}")
public ResponseEntity<String> getPassword(@PathVariable String email) {
return new ResponseEntity<String>(accountService.fetchAccountPassword(email),HttpStatus.OK);
}
public ResponseEntity<String> getPasswordFallback(@PathVariable String email) {
	System.out.println("Email Id entered is wrong!");
	return new ResponseEntity<String>(new String(""),HttpStatus.OK);	
}
	}

package com.data.account.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.data.account.dto.AccountDto;

@Entity
public class AccountEntity {
	@Id
	private String account_email;
	private String account_name;
	private String account_password;
	private String account_type;
	private String old_password;
	public String getOld_password() {
		return old_password;
	}
	public void setOld_password(String old_password) {
		this.old_password = old_password;
	}
	public String getAccount_email() {
		return account_email;
	}
	public void setAccount_email(String account_email) {
		this.account_email = account_email;
	}
	public String getAccount_name() {
		return account_name;
	}
	public void setAccount_name(String account_name) {
		this.account_name = account_name;
	}
	public String getAccount_password() {
		return account_password;
	}
	public void setAccount_password(String account_password) {
		this.account_password = account_password;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public static AccountDto prepareAccountDto(AccountEntity accountEntity) {
		AccountDto accountDto=new AccountDto();
		accountDto.setAccount_email(accountEntity.getAccount_email());
		accountDto.setAccount_name(accountEntity.getAccount_name());
		accountDto.setAccount_password(accountEntity.getAccount_password());
		accountDto.setAccount_type(accountEntity.getAccount_type());
		accountDto.setOld_password(accountEntity.getOld_password());
		return accountDto;
	}
}

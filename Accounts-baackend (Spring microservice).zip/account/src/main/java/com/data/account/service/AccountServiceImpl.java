package com.data.account.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.data.account.dto.AccountDto;
import com.data.account.entity.AccountEntity;
import com.data.account.repo.AccountRepo;


@Service
public class AccountServiceImpl implements AccountService {


@Autowired
private AccountRepo accountRepo;

RestTemplate restTemplate = new RestTemplate();
	

public String createNewAccount(AccountDto accountDetails) {
String password=fetchAccountPassword(accountDetails.getAccount_email());
if(password==null)
{	
AccountEntity ae=AccountDto.prepareAccountEntity(accountDetails);
accountRepo.save(ae);
return "New " +ae.getAccount_type()+" sucessfully added!"; 
}
else {
return "Account already exists!";
}}


public String fetchAccountPassword(String email) {

AccountEntity ae=new AccountEntity();
ae=accountRepo.findById(email).orElse(null);
if(ae==null)
return null;
return ae.getAccount_password();
 }

public String updateAccoutDetails(AccountDto updateDto)throws Exception {

	String original_Password=fetchAccountPassword(updateDto.getAccount_email());
 if(updateDto.getOld_password().equals(original_Password))
		{
	AccountEntity old_Entity=new AccountEntity();
	old_Entity=accountRepo.findById(updateDto.getAccount_email()).orElse(null);
	AccountEntity accountEntity=AccountDto.prepareAccountEntity(updateDto);
	System.out.println(old_Entity.getAccount_name());
	if(updateDto.getAccount_name()==null || updateDto.getAccount_name()=="")
	accountEntity.setAccount_name(old_Entity.getAccount_name());
	if(updateDto.getAccount_password()==null || updateDto.getAccount_password()=="" )
	accountEntity.setAccount_password(old_Entity.getAccount_password());
	accountRepo.save(accountEntity);	
	return "Data updated successfully!";
		}
 	else
	throw new Exception();
}
}

package com.data.account.dto;

import com.data.account.entity.AccountEntity;

public class AccountDto {
private String account_email;
private String account_name;
private String account_password;
private String account_type;
private String old_password;
public String getOld_password() {
	return old_password;
}
public void setOld_password(String old_password) {
	this.old_password = old_password;
}
public String getAccount_email() {
	return account_email;
}
public void setAccount_email(String account_email) {
	this.account_email = account_email;
}
public String getAccount_name() {
	return account_name;
}
public void setAccount_name(String account_name) {
	this.account_name = account_name;
}
public String getAccount_password() {
	return account_password;
}
public void setAccount_password(String account_password) {
	this.account_password = account_password;
}
public String getAccount_type() {
	return account_type;
}
public void setAccount_type(String account_type) {
	this.account_type = account_type;
}
public static AccountEntity prepareAccountEntity(AccountDto accountDto) {
	AccountEntity accountEntity=new AccountEntity();
	accountEntity.setAccount_email(accountDto.getAccount_email());
	accountEntity.setAccount_name(accountDto.getAccount_name());
	accountEntity.setAccount_password(accountDto.getAccount_password());
	accountEntity.setAccount_type(accountDto.getAccount_type());
	accountEntity.setOld_password(accountDto.getOld_password());
	return accountEntity;
}
}

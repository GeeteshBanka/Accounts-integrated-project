package com.data.account.service;

import com.data.account.dto.AccountDto;

public interface AccountService {
	public String createNewAccount(AccountDto accountDetails); 
	public String fetchAccountPassword(String email);
	public String updateAccoutDetails(AccountDto updateDto)throws Exception;
}

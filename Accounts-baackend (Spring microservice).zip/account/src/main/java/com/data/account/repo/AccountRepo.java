package com.data.account.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.data.account.entity.AccountEntity;

public interface AccountRepo extends JpaRepository<AccountEntity,String>{

}
